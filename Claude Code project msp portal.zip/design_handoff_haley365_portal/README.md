# Handoff: Haley365 Client Portal — Dashboard (Executive Summary)

## Overview
The main landing screen of the **Haley365 MSP Client Portal**: a per-client "Executive Summary" dashboard that aggregates reporting across the services Haley365 delivers — **AWS/cloud, support tickets, Huntress security, ScoutDNS, and Microsoft 365**. It is rebranded to match the new Haley365 marketing site (dark navy canvas, blue accent, circuit logo, Archivo + IBM Plex type), so the site and portal read as one product. Primary viewer: **client-side stakeholders (SMB owners / IT managers)**; the same shell also serves Haley365's own techs.

## About the Design Files
These files are **design references** (HTML/JSX prototype) showing intended look, layout, data shape, and spacing. They are **not** meant to ship verbatim — recreate this in the target codebase (**React / Next.js**) using its own patterns, styling convention, routing, and data layer.

- `portal-dashboard-reference.html` — standalone, browser-openable rendering (exact visual truth).
- `PortalDashboard.jsx` — dependency-free, data-driven React component to use as a scaffold.

## Fidelity
**High-fidelity** for visuals (colors, type, spacing, layout are final). **Data is placeholder** — shaped like the real feeds but must be wired to live sources. Values shown as `"—"` mark a feed not yet connected (e.g. ScoutDNS "DNS Blocks Today"); render these with a neutral `muted` tone and an "Awaiting data feed" note until live.

## Layout
Full-height app shell, no page scroll on the chrome; only `<main>` scrolls.
- **Header bar** (60px, bg `#0a0f1a`, bottom hairline): circuit-logo + "HALEY365 / CLIENT PORTAL" lockup at left; right side = **client switcher** ("FPC", a dropdown of the viewer's accessible clients), a notifications button, and a round user avatar ("XG").
- **Tab nav** (48px, bg `#0a0f1a`): Dashboard (active) · AWS · Tickets · Huntress · ScoutDNS · Office 365. Active tab = white text + accent underline + accent icon; inactive = muted. Each routes to its service page.
- **Main** (padding 24, vertical stack, gap 18): page head → KPI row → service cards → two-column lists.

### Page head
- Mono eyebrow "EXECUTIVE SUMMARY" (`#60a5fa`, letter-spacing 0.2em); H1 "Welcome back, {firstName}" (Archivo 800, 26px, white); subtitle "{Client full name} · Last synced {time}".
- Right controls: a **date-range** selector ("Last 30 days") and a solid **Export** button (accent) that generates the client report (PDF/CSV).

### KPI row — 4 cards (`repeat(4,1fr)`, gap 16)
Card: bg `#0e1424`, border `1px solid rgba(96,165,250,0.16)`, radius 12, **3px top border in the metric's tone color**, padding 18/20. Contents: uppercase label + tone-colored icon; big Plex Mono value (34px, tabular-nums, white); muted sub-line.
- EC2 Instances — `64` — "Across all regions" — info
- Open Tickets — `7` — "2 awaiting customer" — warn
- Security Incidents — `0` — "Open · Huntress" — ok
- DNS Blocks Today — `—` — "Awaiting data feed" — muted

### Service summary cards — 3 cards (`repeat(3,1fr)`, gap 16)
Card header: tone icon-chip (30×30, radius 8) + Archivo 700 title + "View →" link to the service tab. Footer: an N-up stat grid separated by a top hairline; each stat = Plex Mono value (22px) over a muted label. A stat can carry its own tone color (e.g. Open=warn, Closed=ok).
- **AWS Resources** (info): Instances 64 · Volumes 151 · Snapshots 2,394
- **Support Tickets** (warn): Open 7 (warn) · In Progress 0 · Closed 3,198 (ok)
- **Huntress Security** (ok): Total Agents 87 · Open Incidents 0 (ok) · Critical —

### Two-column lists (`repeat(2,1fr)`, gap 16)
Both are cards with an Archivo 700 title + "All … →" link, then rows separated by top hairlines.
- **Recent Tickets** — each row: subject (ellipsized) + date, with a status pill. Statuses & tones: Customer Reply (warn), Waiting On Customer (purple), Resolved (ok). Rows: Littleton VPN / Foley Titan setup / Foley Incident Reports / Cantonment Internet Down / St Martinville Internet.
- **Recent Security Incidents** — each row: tone icon-chip + title + state ("Closed") + severity pill. High (purple, `gpp_maybe` icon), Low (muted, `info` icon).

## Interactions & Behavior
- **Client switcher** changes the active account and re-fetches every widget for that client (scope all data by client id).
- **Tabs** route to service detail pages: `/dashboard`, `/aws`, `/tickets`, `/huntress`, `/scoutdns`, `/office365`.
- **Date range** filters time-bound metrics (tickets, DNS blocks, incidents). **Export** produces the client report for the current client + range.
- **"View" / "All …" links** deep-link into the relevant service tab (optionally pre-filtered).
- **Hover** (add per codebase convention): cards lift slightly + border → `rgba(96,165,250,0.4)`; buttons brighten; tab hover → white text.
- **Loading**: skeleton the KPI values and list rows while fetching. **Empty/unwired feed**: show `—` + a muted note (as with ScoutDNS). **Error**: per-widget inline error state rather than failing the whole page.
- **Responsive**: KPI grid 4→2→1; service cards 3→1; two-column lists stack; header controls collapse/wrap on narrow widths. Reference is desktop; implement fluid breakpoints.

## State Management
- **Server data** per client: AWS resource counts, ticket stats + recent tickets, Huntress agents/incidents, ScoutDNS blocks, M365 (future). Fetch by `clientId` + `dateRange`; cache per client (e.g. React Query / server components + suspense).
- **UI state**: active client, active tab (route-driven), selected date range.
- Auth/session determines which clients the viewer can access and populates the switcher + "Welcome, {firstName}".

## Design Tokens
**Colors**
- App bg `#0c111e`; chrome bg (header/tabs) `#0a0f1a`; card bg `#0e1424`
- Card border `rgba(96,165,250,0.16)`; hairline `rgba(255,255,255,0.07)`
- Accent (primary/CTA/active) `#2f6bff`; logo blue `#3b82f6`; link/icon blue `#7cb0ff`; eyebrow `#60a5fa`
- Text: white `#fff`; primary body `#eaf0fb`; secondary `#c4cede`; muted `#8a97ab`; faint `#7f8ea3`
- Status tones (fg / bg): ok `#4ade80` / `rgba(74,222,128,0.12)`; warn `#fbbf24` / `rgba(251,191,36,0.14)`; crit `#f87171` / `rgba(248,113,113,0.14)`; info `#7cb0ff` / `rgba(124,176,255,0.14)`; purple `#c4b5fd` / `rgba(196,181,253,0.14)`; muted `#9aa6b8` / `rgba(154,166,184,0.12)`

**Typography**
- Headings/titles: **Archivo** (700/800). Body/UI: **IBM Plex Sans** (400–700). Numbers & eyebrows: **IBM Plex Mono** (500/600), `font-variant-numeric: tabular-nums` on all metric figures.
- Scale: H1 26 / card title 15 / KPI value 34 / stat value 22 / body 13.5 / label 11.5–12 / eyebrow 11.5.

**Spacing / shape** — main padding 24; grid gaps 16; card padding 18–20; radii: cards 12, chips/buttons 8–9, pills 999. Status pills: `padding 3px 11px`, 11.5px, weight 600.

## Assets
- **Logo:** inline circuit-node SVG (in both files). Swap for official Haley365 SVG when available.
- **Icons:** Material Symbols Rounded — `dashboard, cloud, confirmation_number, shield, dns, mail, block, apartment, notifications, calendar_today, download, arrow_forward, gpp_maybe, info`. Swap for the project's icon set if preferred.
- **Fonts:** Google Fonts (Archivo, IBM Plex Sans, IBM Plex Mono) — prefer `next/font/google`.

## Files
- `design_handoff_haley365_portal/portal-dashboard-reference.html` — standalone visual reference.
- `design_handoff_haley365_portal/PortalDashboard.jsx` — React scaffold (data-driven, inline styles).
- Companion homepage handoff lives in `design_handoff_haley365_homepage/` — shares the same tokens/brand.

## Notes for implementation
- Suggested structure: an `<AppShell>` (header + tab nav, shared across all service pages) wrapping route content; the dashboard = `<PageHead> <KpiRow> <ServiceCards> <RecentTickets> <RecentIncidents>`. Keep the data arrays as typed models fed by the API.
- Centralize the `TONE` map (status → fg/bg) and the `pill()` / card / hairline styles as shared tokens/components so every service page stays consistent.
- If Tailwind: map tokens to `tailwind.config` (colors, fontFamily) and convert inline styles to utilities; encode tones as a small variant helper.
- The **other five tabs are not designed yet** — this is the dashboard only. When ready, the same shell + card/list/KPI vocabulary extends to each service page (AWS, Tickets, Huntress, ScoutDNS, Office 365).
- Keep `"—"` + "Awaiting data feed" for any metric whose source isn't live yet, so the UI is honest during rollout.
