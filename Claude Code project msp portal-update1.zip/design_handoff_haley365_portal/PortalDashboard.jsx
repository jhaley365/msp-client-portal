/**
 * Haley365 — Client Portal Dashboard ("Executive Summary")
 * --------------------------------------------------------
 * Production-ready React component, data-driven and dependency-free.
 * Works as a Next.js page/route or a component in any React app.
 *
 * FONTS (load once, e.g. app/layout.jsx or next/font):
 *   Archivo (600/700/800), IBM Plex Sans (400/500/600/700), IBM Plex Mono (500/600),
 *   Material Symbols Rounded (icons).
 *
 * ADAPTATION NOTES for Claude Code:
 *   - Inline styles are used for a faithful, dependency-free reference. Convert to the
 *     project's convention (Tailwind / CSS Modules / styled-components).
 *   - The data arrays (TABS, KPIS, SERVICE_CARDS, TICKETS, INCIDENTS) are placeholders
 *     shaped like the real feeds. Replace with live data from AWS, the ticketing system,
 *     Huntress, ScoutDNS, and Microsoft 365. Keep the same field shapes and the `tone`
 *     -> color mapping so status colors stay consistent.
 *   - Tabs are non-functional here (Dashboard is active). Wire to routes:
 *     /dashboard, /aws, /tickets, /huntress, /scoutdns, /office365.
 *   - "—" values indicate a data feed not yet wired (e.g. ScoutDNS). Render a neutral
 *     "muted" tone + an "Awaiting data feed" note until the feed is live.
 */

const ACCENT = "#2f6bff";

// tone -> {fg, bg}. Tuned for a dark (#0c111e) canvas.
const TONE = {
  ok:     { fg: "#4ade80", bg: "rgba(74,222,128,0.12)" },
  warn:   { fg: "#fbbf24", bg: "rgba(251,191,36,0.14)" },
  crit:   { fg: "#f87171", bg: "rgba(248,113,113,0.14)" },
  info:   { fg: "#7cb0ff", bg: "rgba(124,176,255,0.14)" },
  purple: { fg: "#c4b5fd", bg: "rgba(196,181,253,0.14)" },
  muted:  { fg: "#9aa6b8", bg: "rgba(154,166,184,0.12)" },
};

const pill = (tone) => ({
  display: "inline-flex", alignItems: "center", padding: "3px 11px",
  borderRadius: 999, fontSize: 11.5, fontWeight: 600, whiteSpace: "nowrap",
  color: TONE[tone].fg, background: TONE[tone].bg,
});

const TABS = [
  { label: "Dashboard",  icon: "dashboard",           href: "/dashboard",  active: true },
  { label: "AWS",        icon: "cloud",               href: "/aws" },
  { label: "Tickets",    icon: "confirmation_number", href: "/tickets" },
  { label: "Huntress",   icon: "shield",              href: "/huntress" },
  { label: "ScoutDNS",   icon: "dns",                 href: "/scoutdns" },
  { label: "Office 365", icon: "mail",                href: "/office365" },
];

const KPIS = [
  { label: "EC2 Instances",      icon: "dns",                 value: "64", unit: "", sub: "Across all regions",  tone: "info" },
  { label: "Open Tickets",       icon: "confirmation_number", value: "7",  unit: "", sub: "2 awaiting customer", tone: "warn" },
  { label: "Security Incidents", icon: "shield",              value: "0",  unit: "", sub: "Open · Huntress",     tone: "ok" },
  { label: "DNS Blocks Today",   icon: "block",               value: "—",  unit: "", sub: "Awaiting data feed",  tone: "muted" },
];

const SERVICE_CARDS = [
  { title: "AWS Resources", icon: "cloud", tone: "info", stats: [
    { value: "64", label: "Instances" }, { value: "151", label: "Volumes" }, { value: "2,394", label: "Snapshots" },
  ] },
  { title: "Support Tickets", icon: "confirmation_number", tone: "warn", stats: [
    { value: "7", label: "Open", tone: "warn" }, { value: "0", label: "In Progress" }, { value: "3,198", label: "Closed", tone: "ok" },
  ] },
  { title: "Huntress Security", icon: "shield", tone: "ok", stats: [
    { value: "87", label: "Total Agents" }, { value: "0", label: "Open Incidents", tone: "ok" }, { value: "—", label: "Critical" },
  ] },
];

const TICKETS = [
  { subject: "Littleton – Unable to connect to VPN", date: "7/2/2026", status: "Customer Reply",      tone: "warn" },
  { subject: "RE: Foley Titan account setup",        date: "7/1/2026", status: "Waiting On Customer", tone: "purple" },
  { subject: "Foley Incident Reports",               date: "7/1/2026", status: "Resolved",            tone: "ok" },
  { subject: "Cantonment Internet Down",             date: "7/1/2026", status: "Resolved",            tone: "ok" },
  { subject: "St Martinville Internet",              date: "7/1/2026", status: "Resolved",            tone: "ok" },
];

const INCIDENTS = [
  { title: "Suspicious PowerShell execution",    state: "Closed", sev: "High", tone: "purple", icon: "gpp_maybe" },
  { title: "LOW – Potentially insecure service", state: "Closed", sev: "Low",  tone: "muted",  icon: "info" },
  { title: "LOW – Potentially insecure service", state: "Closed", sev: "Low",  tone: "muted",  icon: "info" },
  { title: "LOW – Potentially insecure service", state: "Closed", sev: "Low",  tone: "muted",  icon: "info" },
  { title: "LOW – Potentially insecure service", state: "Closed", sev: "Low",  tone: "muted",  icon: "info" },
];

function Icon({ name, style }) {
  return <span className="material-symbols-rounded" style={{ fontFamily: "'Material Symbols Rounded'", lineHeight: 1, ...style }}>{name}</span>;
}

const CARD = { background: "#0e1424", border: "1px solid rgba(96,165,250,0.16)", borderRadius: 12 };
const HAIRLINE = "1px solid rgba(255,255,255,0.07)";

function Logo() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
      <svg width="34" height="34" viewBox="0 0 48 48" fill="none" style={{ flex: "none" }}>
        <g transform="rotate(-28 24 24)">
          <ellipse cx="24" cy="24" rx="18" ry="8.5" stroke="#3b82f6" strokeWidth="2.2" fill="none" />
          <circle cx="42" cy="24" r="3.2" fill="#3b82f6" />
        </g>
        <circle cx="24" cy="24" r="4.4" fill="#fff" />
      </svg>
      <div style={{ display: "flex", flexDirection: "column", lineHeight: 1 }}>
        <span style={{ fontFamily: "'Archivo',sans-serif", fontWeight: 800, letterSpacing: "0.14em", fontSize: 15, color: "#fff" }}>HALEY365</span>
        <span style={{ fontSize: 8, letterSpacing: "0.24em", color: "#7f8ea3", marginTop: 3 }}>CLIENT PORTAL</span>
      </div>
    </div>
  );
}

export default function PortalDashboard() {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden", background: "#0c111e", color: "#eaf0fb", fontFamily: "'IBM Plex Sans',system-ui,sans-serif" }}>

      {/* HEADER */}
      <header style={{ flex: "none", background: "#0a0f1a", borderBottom: HAIRLINE, height: 60, display: "flex", alignItems: "center", gap: 16, padding: "0 24px" }}>
        <Logo />
        <div style={{ flex: 1 }} />
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 12px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
          <Icon name="apartment" style={{ fontSize: 17, color: "#8a97ab" }} />FPC<Icon name="expand_more" style={{ fontSize: 18, color: "#8a97ab" }} />
        </div>
        <button style={{ width: 38, height: 38, border: "1px solid rgba(255,255,255,0.12)", borderRadius: 9, background: "rgba(255,255,255,0.04)", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
          <Icon name="notifications" style={{ fontSize: 19, color: "#c4cede" }} />
        </button>
        <div style={{ width: 36, height: 36, borderRadius: "50%", background: ACCENT, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700 }}>XG</div>
      </header>

      {/* TABS */}
      <nav style={{ flex: "none", background: "#0a0f1a", borderBottom: HAIRLINE, height: 48, display: "flex", alignItems: "stretch", padding: "0 24px", gap: 2 }}>
        {TABS.map((t) => (
          <a key={t.label} href={t.href} style={{ display: "flex", alignItems: "center", gap: 8, padding: "0 15px", textDecoration: "none", fontSize: 13.5, fontWeight: t.active ? 700 : 500, color: t.active ? "#fff" : "#8a97ab", borderBottom: `2px solid ${t.active ? ACCENT : "transparent"}`, marginBottom: -1 }}>
            <Icon name={t.icon} style={{ fontSize: 18, color: t.active ? ACCENT : "#7f8ea3" }} />{t.label}
          </a>
        ))}
      </nav>

      {/* MAIN */}
      <main style={{ flex: 1, overflowY: "auto", padding: 24, display: "flex", flexDirection: "column", gap: 18 }}>

        {/* Page head */}
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 11.5, letterSpacing: "0.2em", color: "#60a5fa", marginBottom: 8 }}>EXECUTIVE SUMMARY</div>
            <h1 style={{ margin: 0, fontFamily: "'Archivo',sans-serif", fontSize: 26, fontWeight: 800, letterSpacing: "-0.01em", color: "#fff" }}>Welcome back, XG</h1>
            <div style={{ fontSize: 13, color: "#8a97ab", marginTop: 5 }}>Foley Products Co. (FPC) · Last synced 4:14:54 PM</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "8px 13px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 9, fontSize: 13, fontWeight: 500, color: "#c4cede", cursor: "pointer" }}>
              <Icon name="calendar_today" style={{ fontSize: 17, color: "#8a97ab" }} />Last 30 days<Icon name="expand_more" style={{ fontSize: 18, color: "#8a97ab" }} />
            </div>
            <button style={{ display: "flex", alignItems: "center", gap: 7, padding: "9px 15px", border: "none", borderRadius: 9, background: ACCENT, color: "#fff", fontFamily: "inherit", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              <Icon name="download" style={{ fontSize: 17 }} />Export
            </button>
          </div>
        </div>

        {/* KPI row */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,minmax(0,1fr))", gap: 16 }}>
          {KPIS.map((k) => (
            <div key={k.label} style={{ ...CARD, borderTop: `3px solid ${TONE[k.tone].fg}`, padding: "18px 20px" }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
                <span style={{ fontSize: 11.5, fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase", color: "#8a97ab" }}>{k.label}</span>
                <Icon name={k.icon} style={{ fontSize: 22, color: TONE[k.tone].fg }} />
              </div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginTop: 14 }}>
                <span style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 34, fontWeight: 600, color: "#fff", fontVariantNumeric: "tabular-nums", lineHeight: 1 }}>{k.value}</span>
                {k.unit && <span style={{ fontSize: 15, fontWeight: 500, color: "#7f8ea3" }}>{k.unit}</span>}
              </div>
              <div style={{ fontSize: 12, color: "#8a97ab", marginTop: 9 }}>{k.sub}</div>
            </div>
          ))}
        </div>

        {/* Service summary cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: 16 }}>
          {SERVICE_CARDS.map((c) => (
            <div key={c.title} style={{ ...CARD, padding: "18px 20px 20px" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                  <Icon name={c.icon} style={{ fontSize: 18, width: 30, height: 30, borderRadius: 8, display: "inline-flex", alignItems: "center", justifyContent: "center", color: TONE[c.tone].fg, background: TONE[c.tone].bg }} />
                  <span style={{ fontFamily: "'Archivo',sans-serif", fontSize: 15, fontWeight: 700, color: "#fff" }}>{c.title}</span>
                </div>
                <a href="#" style={{ fontSize: 12.5, fontWeight: 600, color: "#7cb0ff", textDecoration: "none", display: "flex", alignItems: "center", gap: 3 }}>View<Icon name="arrow_forward" style={{ fontSize: 15 }} /></a>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: `repeat(${c.stats.length},minmax(0,1fr))`, gap: 8, paddingTop: 16, borderTop: HAIRLINE }}>
                {c.stats.map((s) => (
                  <div key={s.label} style={{ textAlign: "center" }}>
                    <div style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 22, fontWeight: 600, color: s.tone ? TONE[s.tone].fg : "#fff", fontVariantNumeric: "tabular-nums" }}>{s.value}</div>
                    <div style={{ fontSize: 11.5, color: "#8a97ab", marginTop: 4 }}>{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Two-column lists */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 16, alignItems: "start" }}>
          {/* Recent tickets */}
          <div style={{ ...CARD, padding: "18px 20px 8px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
              <div style={{ fontFamily: "'Archivo',sans-serif", fontSize: 15, fontWeight: 700, color: "#fff" }}>Recent Tickets</div>
              <a href="#" style={{ fontSize: 12.5, fontWeight: 600, color: "#7cb0ff", textDecoration: "none", display: "flex", alignItems: "center", gap: 3 }}>All tickets<Icon name="arrow_forward" style={{ fontSize: 15 }} /></a>
            </div>
            {TICKETS.map((t, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 0", borderTop: HAIRLINE }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600, color: "#eaf0fb", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.subject}</div>
                  <div style={{ fontSize: 12, color: "#7f8ea3", marginTop: 3 }}>{t.date}</div>
                </div>
                <span style={pill(t.tone)}>{t.status}</span>
              </div>
            ))}
          </div>
          {/* Recent incidents */}
          <div style={{ ...CARD, padding: "18px 20px 8px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
              <div style={{ fontFamily: "'Archivo',sans-serif", fontSize: 15, fontWeight: 700, color: "#fff" }}>Recent Security Incidents</div>
              <a href="#" style={{ fontSize: 12.5, fontWeight: 600, color: "#7cb0ff", textDecoration: "none", display: "flex", alignItems: "center", gap: 3 }}>All incidents<Icon name="arrow_forward" style={{ fontSize: 15 }} /></a>
            </div>
            {INCIDENTS.map((inc, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 0", borderTop: HAIRLINE }}>
                <Icon name={inc.icon} style={{ fontSize: 18, width: 32, height: 32, borderRadius: 8, display: "inline-flex", alignItems: "center", justifyContent: "center", color: TONE[inc.tone].fg, background: TONE[inc.tone].bg }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600, color: "#eaf0fb", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{inc.title}</div>
                  <div style={{ fontSize: 12, color: "#7f8ea3", marginTop: 3 }}>{inc.state}</div>
                </div>
                <span style={pill(inc.tone)}>{inc.sev}</span>
              </div>
            ))}
          </div>
        </div>

      </main>
    </div>
  );
}
